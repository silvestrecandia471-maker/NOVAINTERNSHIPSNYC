import { NYC_INTERNSHIPS } from '../components/InternshipFinderNYC'

export async function fetchNYCInternships({ query }) {
  await new Promise((r) => setTimeout(r, 500))
  if (!query) return NYC_INTERNSHIPS
  const q = query.toLowerCase()
  return NYC_INTERNSHIPS.filter(
    (i) =>
      i.title.toLowerCase().includes(q) ||
      i.company.toLowerCase().includes(q) ||
      i.industry.toLowerCase().includes(q)
  )
}