import InternshipFinderNYC from './components/InternshipFinderNYC'

export default function App() {
  return (
    <div>
      <InternshipFinderNYC />
    </div>
  )
}