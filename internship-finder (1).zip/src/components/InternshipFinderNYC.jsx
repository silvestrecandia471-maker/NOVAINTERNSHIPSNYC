import React, { useEffect, useState } from 'react'
import { fetchNYCInternships } from '../api/jobsApi'

export const NYC_INTERNSHIPS = [
  {
    id: "jpm-nyc-ib-analyst",
    title: "Investment Banking Summer Analyst",
    company: "JP Morgan",
    industry: "Investment Banking",
    location: "New York, NY",
    remote: false,
    paid: true,
    posted: "2025-10-15",
    description: "Assist in deal execution, prepare pitch books, and perform valuation analyses.",
    applyUrl: "https://careers.jpmorgan.com/us/en/students/programs/summer-analyst"
  },
  {
    id: "citi-nyc-markets-analyst",
    title: "Markets Summer Analyst Program",
    company: "Citi",
    industry: "Markets",
    location: "New York, NY",
    remote: false,
    paid: true,
    posted: "2025-10-10",
    description: "Work on trading, sales, and research desks across asset classes.",
    applyUrl: "https://www.citi.com/careers/students/"
  },
  {
    id: "ms-nyc-wealth-analyst",
    title: "Wealth Management Internship",
    company: "Morgan Stanley",
    industry: "Wealth Management",
    location: "New York, NY",
    remote: false,
    paid: true,
    posted: "2025-10-05",
    description: "Support financial advisors, create client presentations, and assist with portfolio analysis.",
    applyUrl: "https://www.morganstanley.com/people-opportunities/students-graduates"
  },
  {
    id: "goldman-nyc-globalmarkets",
    title: "Global Markets Summer Analyst",
    company: "Goldman Sachs",
    industry: "Global Markets",
    location: "New York, NY",
    remote: false,
    paid: true,
    posted: "2025-09-25",
    description: "Support trading and structuring teams, analyze market data, and research macro trends.",
    applyUrl: "https://www.goldmansachs.com/careers/students/"
  },
  {
    id: "evercore-nyc-summer-analyst",
    title: "Investment Banking Summer Analyst",
    company: "Evercore",
    industry: "Investment Banking",
    location: "New York, NY",
    remote: false,
    paid: true,
    posted: "2025-09-20",
    description: "Assist senior bankers with client presentations, research, and transaction support.",
    applyUrl: "https://www.evercore.com/join-us/students/"
  },
  {
    id: "jefferies-nyc-summer-analyst",
    title: "Investment Banking Summer Analyst",
    company: "Jefferies",
    industry: "Investment Banking",
    location: "New York, NY",
    remote: false,
    paid: true,
    posted: "2025-09-15",
    description: "Develop financial models, analyze industry trends, and assist in M&A transactions.",
    applyUrl: "https://careers.jefferies.com/students/"
  },
  {
    id: "blackrock-nyc-analyst",
    title: "Summer Analyst Program — Investments",
    company: "BlackRock",
    industry: "Asset Management",
    location: "New York, NY",
    remote: false,
    paid: true,
    posted: "2025-08-30",
    description: "Assist portfolio managers and contribute to research across asset classes.",
    applyUrl: "https://careers.blackrock.com/early-careers/"
  }
]

export default function InternshipFinderNYC() {
  const [query, setQuery] = useState('')
  const [internships, setInternships] = useState([])
  const [favorites, setFavorites] = useState({})
  const [selected, setSelected] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('nyc_favorites_v1')
    if (saved) setFavorites(JSON.parse(saved))
  }, [])

  useEffect(() => {
    localStorage.setItem('nyc_favorites_v1', JSON.stringify(favorites))
  }, [favorites])

  useEffect(() => {
    const load = async () => {
      setLoading(true)
      try {
        const list = await fetchNYCInternships({ query })
        setInternships(list)
      } catch (err) {
        console.error('Fetch error:', err)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [query])

  function toggleFavorite(id) {
    setFavorites(prev => {
      const c = { ...prev }
      if (c[id]) delete c[id]
      else c[id] = true
      return c
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">NYC Internship Finder</h1>
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search by company, title, or industry"
          className="w-full p-2 border rounded mb-6"
        />
        {loading && <p>Loading...</p>}
        {!loading && internships.map(i => (
          <div key={i.id} className="bg-white p-4 rounded shadow mb-4 flex justify-between">
            <div>
              <h2 className="font-semibold">{i.title}</h2>
              <p className="text-sm text-gray-600">{i.company} - {i.industry}</p>
              <p className="text-sm mt-2">{i.description}</p>
              <a href={i.applyUrl} target="_blank" rel="noreferrer" className="text-indigo-600 text-sm mt-2 inline-block">Apply</a>
            </div>
            <button onClick={() => toggleFavorite(i.id)} className={`text-sm ${favorites[i.id] ? 'text-yellow-500' : 'text-gray-400'}`}>
              {favorites[i.id] ? '★' : '☆'}
            </button>
          </div>
        ))}
        {!loading && internships.length === 0 && <p>No internships found.</p>}
      </div>
    </div>
  )
}